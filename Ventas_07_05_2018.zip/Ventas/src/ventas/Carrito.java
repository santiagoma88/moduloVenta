/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

import java.util.ArrayList;
import java.util.List;

/**
 *Carrito de compras, implementado con una Lista de "CuatroTupla" en las que se guardan
 * producto,cantidad/unidades, precio base, porcentaje de modificacion(descuentos,recargos)
 * @author Administrador
 */
public class Carrito implements ICarrito {

    private List<CuatroTupla> carrito;
    
    /**
     * Crea un carrito vacio
     */
    public Carrito() {
        this.carrito = new ArrayList<>();
    }

    @Override
    public boolean anadirElemento(AbstractProducto producto, int cantidad) {        
        if(indiceElementoCarrito(producto)==-1){//objeto no esta actualmente en el carrito
            if(cantidad<0 || producto.esServicio()){
                cantidad=1;
            }
            CuatroTupla nt = new CuatroTupla(producto, cantidad);
        carrito.add(nt);
        return true;
        }else{
            return false;
        }        
    }

    /**
     *Indice de el elemento dentro del carrito
     * Comprara utilizando AbstractProducto.equals() {@link AbstractProducto#equals(java.lang.Object) }
     * @return  -1 si no esta o el indice
     */
    private int indiceElementoCarrito(AbstractProducto abstractProducto) {
        int i = 0;
        for (CuatroTupla nt : carrito) {
            if (nt.getProducto().equals(abstractProducto)) {
                return i;
            }
            i++;
        }
        
        return -1;
    }

    @Override
    public boolean eliminarElemento(AbstractProducto producto) {
        int indice = indiceElementoCarrito(producto);
        if (indice == -1) {
            return false;
        } else {
            carrito.remove(indice);
            return true;
        }
    }

    @Override
    public void vaciarCarrito() {
        this.carrito.clear();
    }

    /**
     *
     * @return List de cuatroTupla en la que se encuentra cada producto de el carrito , asi como su cantidad 
     */
    public List<CuatroTupla> getCarrito() {
        return carrito;
    }

    @Override
    public String toString() {
        String aux="Carrito{\n";
        for(CuatroTupla nT: this.carrito){
            aux+=nT.toString()+"\n";
        }
        return aux;
    }
    

}
