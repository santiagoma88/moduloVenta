/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

/**
 *
 * @author Administrador
 */
public interface IVenta {
    public double getTotal();
    
    /**
     * se debe definir como retornarlas
     */
    public void getFechas();
    
    
}
