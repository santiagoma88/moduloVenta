/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

/**
 *Impuestos dependiendo del tipo de cliente y su porcentaje asociado
 * //Se debe definir mejor segun las escpecificaciones del problema
 * @author Administrador
 */
public class RecargoODescuento {
    private boolean aplicaPersona;
    private double porcentaje;

    /**
     *creo recargo o descuento a la venta i.e Impuesto y a ue tipo de clientte aplica
     * @param aplicaPersona el recargo o descuento aplica a persona o institucion
     * @param porcentaje porcentaje de cambio: +recargo/-descuento
     */
    public RecargoODescuento(boolean aplicaPersona, double porcentaje) {
        this.aplicaPersona = aplicaPersona;
        this.porcentaje = porcentaje;
    }

    public boolean aplicaAPersona() {
        return aplicaPersona;
    }

    public double getPorcentaje() {
        return porcentaje;
    }
    
}
