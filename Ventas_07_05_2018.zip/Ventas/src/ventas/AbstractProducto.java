/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

/**
 *Clase abstracte de los productos, los cuales pueden ser bienes o servicios
 * @author Administrador
 */
public abstract class AbstractProducto {

    private String nombre;
    private boolean esServicio;
    private String fechaEstimada;
    private double precioBrutoUnidad;
    private String descripcion;

    protected AbstractProducto(String nombre, boolean esServicio, String fechaEstimada, double precioBrutoUnidad,String descripcion ) {
        this.nombre = nombre;
        this.esServicio = esServicio;
        this.fechaEstimada = fechaEstimada;
        this.precioBrutoUnidad = precioBrutoUnidad;
        this.descripcion=descripcion;
    }

    /**
     *
     * @return nombre de el producto
     */
    public String getNombre() {
        return nombre;
    }

    /**
     *
     * @return true si es servicio, false si es bien(producto fisico)
     */
    public boolean esServicio() {
        return esServicio;
    }

    /**
     *
     * @return fecha de entrega estimada o de prestacion de servicios
     */
    public String getFechaEstimada() {
        return fechaEstimada;
    }

    /**
     *
     * @return precio por unidad del producto
     */
    public double getPrecioBrutoUnidad() {
        return precioBrutoUnidad;
    }
    public String getDescripcion(){
        return descripcion;
    }
    
    /**
     * @see Bien#equals(java.lang.Object) igualdad de un bien
     * @see Servicio#equals(java.lang.Object) igualdad de un servicio
     * 
    */
    @Override
    public abstract boolean equals(Object other);

    
    
    
}
