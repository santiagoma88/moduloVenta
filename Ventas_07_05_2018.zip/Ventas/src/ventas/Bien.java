/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

/**
 *Bien (producto fisico)que se vende
 * @author Administrador
 */
public class Bien extends AbstractProducto{    
  
    /**
     * Crea un nuevo bien(producto fisico)
     *
     * @param nombre nombre del producto
     * @param fechaEstimada fecha estimada de entrega
     * @param precioBrutoUnidad precio por unidad
     * @param descripcion descripcion del producto    
     */
    public Bien(String nombre, String fechaEstimada, double precioBrutoUnidad,String descripcion) {
        super(nombre, false , fechaEstimada, precioBrutoUnidad, descripcion);      
        
    }   
    /**
     * Un bien es igual a otro si tienen el mismo nombre
     * @param obj objeto a comparar
     * @return true si el obj es igual a this false en caso contrario
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Bien other = (Bien) obj;
        if (!this.getNombre().equals(other.getNombre())) {
            return false;
        }        
        return true;
    }

    @Override
    public String toString() {        
        return "Bien: " + this.getNombre() +  ",\tfechaEstimadaEntrega: " + this.getFechaEstimada() + 
                ",\tprecioPorUnidad: " + this.getPrecioBrutoUnidad()+",\tdescrpcion: "+this.getDescripcion();       
    }
    
    
    
}
