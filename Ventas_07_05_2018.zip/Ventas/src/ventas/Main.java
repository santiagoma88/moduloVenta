/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

/**
 *
 * @author Administrador
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
                    ¡¡¡¡¡¡¡¡¡¡¡¡IMPORTANTE!!!!!!!!!!!!!
                    ¡¡¡¡¡¡¡¡¡¡¡¡IMPORTANTE!!!!!!!!!!!!!
                    ¡¡¡¡¡¡¡¡¡¡¡¡IMPORTANTE!!!!!!!!!!!!!
                    ¡¡¡¡¡¡¡¡¡¡¡¡IMPORTANTE!!!!!!!!!!!!!
        Para realizar una venta se deben primero crear los productos(bienes y servicios)
        Luego crear un carrito precioUnidad r añadiendo y/o eliminado productos
        Se crea un cliente , y unrecargoODescuento
        p.e 
        *si se crea un recargoODescuent (true//(aplicaAPersona)//,18),este sera un 
        recargo que se le aplicara a los cilentes que son personas del 18% sobre 
        el valor de la compra //IVA//
        *(false,-20) =descuento de 20% para instituciones
        Cuando se este seguro de el carrito, se crea una venta(se deben tener un carrito, un cliente, y un recargoODescuento)
        la venta se hace con procesos internos y proporciona metodos para acceder a diferentes valores o atributos de interes
        */
        int precioUnidad=1000;
        
        //
        //Creacion de productos
        //
        
        boolean dentroAreaM=true;
        boolean fueraAreaM=false;
        AbstractProducto[] productos ={
            new Bien("Bien1", "fechaEstimada1", 1000,"descripcion"),  //0
            new Bien("Bien1", "fechaEstimada1", 6000,"descripcion"),  //1
            new Bien("Bien2", "fechaEstimada2", 2000,"descripcion"),  //2
            new Bien("Bien2", "fechaEstimada3", 3000,"descripcion"),  //3
            new Bien("Bien3", "fechaEstimada4", 4000,"descripcion"),  //4
            new Bien("Bien4", "fechaEstimada4", 3000,"descripcion"),  //5       
            new Bien("Bien5", "fechaEstimada7", 7000,"descripcion"),  //6
            new Servicio("servicio1", "fechaEstimada1", precioUnidad, "facilitador1", "direccion", fueraAreaM,"descripcion"), //7
            new Servicio("servicio2", "fechaEstimada2", precioUnidad, "facilitador1", "direccion", dentroAreaM,"descripcion"), //8
            new Servicio("servicio2", "fechaEstimada2", precioUnidad, "facilitador1", "direccion", fueraAreaM,"descripcion"), //9
            new Servicio("servicio2", "fechaEstimada2", precioUnidad, "facilitador2", "direccion", fueraAreaM,"descripcion"), //10
            new Servicio("servicio4", "fechaEstimada3", precioUnidad, "facilitador3", "direccion", fueraAreaM,"descripcion"), //11
        };
        
        AbstractProducto dele1=new Servicio("servicio3", "fechaEstimada2", 1, "facilitador3", "direccion", false, "descripcion");
        AbstractProducto dele2=new Servicio("servicio4", "fechaEstimada2", 1, "facilitador3", "direccion", false, "descripcion");
        AbstractProducto dele3=new Servicio("servicio4", "fechaEstimada3", 1, "facilitador2", "direccion", false, "descripcion");
        AbstractProducto dele4=new Servicio("servicio3", "fechaEstimada3", 1, "facilitador3", "direccion", false, "descripcion");
        AbstractProducto dele5=new Servicio("servicio4", "fechaEstimada3", 1, "facilitador3", "direccion", false, "descripcion");
               
        //
        //Creacion de carrito
        //
        Carrito shoppigCart =new Carrito();      
            
                   
        
        //
        //Adicion de objetos al carrito
        //
        for(int j=0; j<=11;j++){
            System.out.print("Se intento añadir el elemento "+j+"\t");    
        System.out.println(shoppigCart.anadirElemento(productos[j], 10+j));
        System.out.println(shoppigCart.toString());
        }
        
        //
        //Eliminacion de objetos del carrito
        //
        System.out.print("Se intento eliminar el elemento "+0+"\t");    
        System.out.println(shoppigCart.eliminarElemento(productos[0]));
        System.out.println(shoppigCart.toString());
        System.out.print("Se intento eliminar el elemento "+5+"\t");    
        System.out.println(shoppigCart.eliminarElemento(productos[5]));
        System.out.println(shoppigCart.toString());
        System.out.print("Se intento eliminar el elemento "+9+"\t");    
        System.out.println(shoppigCart.eliminarElemento(productos[9]));
        System.out.println(shoppigCart.toString()); 
        System.out.print("Se intento eliminar el elemento "+9+"\t");    
        System.out.println(shoppigCart.eliminarElemento(productos[9]));
        System.out.println(shoppigCart.toString());         
        System.out.print("Se intento eliminar el elemento dele1\t");    
        System.out.println(shoppigCart.eliminarElemento(dele1));
        System.out.println(shoppigCart.toString());
        System.out.print("Se intento eliminar el elemento dele2\t");    
        System.out.println(shoppigCart.eliminarElemento(dele2));
        System.out.println(shoppigCart.toString());
        System.out.print("Se intento eliminar el elemento dele3\t");    
        System.out.println(shoppigCart.eliminarElemento(dele3));
        System.out.println(shoppigCart.toString());
        System.out.print("Se intento eliminar el elemento dele4\t");    
        System.out.println(shoppigCart.eliminarElemento(dele4));
        System.out.println(shoppigCart.toString());
        System.out.print("Se intento eliminar el elemento dele5\t");    
        System.out.println(shoppigCart.eliminarElemento(dele5));
        System.out.println(shoppigCart.toString());  
        
        
        //
        //Creacion de diferenates clientes
        //
        Cliente c1=new Cliente(true, "1", "nombre1", "contacto");  
        Cliente c2=new Cliente(true, "2", "nombre2", "contacto");
        Cliente c3=new Cliente(true, "3", "nombre3", "contacto");
        Cliente c4=new Cliente(false, "1", "nombre4", "contacto");
        Cliente c5=new Cliente(true, "1", "nombre5", "contacto");
        Cliente c6=new Cliente(true,"2", "nombre6", "contacto");
        
        
        
         //                                                           
         //Creacion de recargoODescuento                                                           
         //                                                           
        RecargoODescuento recargoODescuento=new RecargoODescuento(false,18);//aplica a persona
        
        
        
        //
        //Creacion de venta
        //      
        Venta venta=new Venta(shoppigCart, c4, recargoODescuento);
        System.out.println(venta.getTotal());
        System.out.println(shoppigCart.toString());

        
    }
    
}
