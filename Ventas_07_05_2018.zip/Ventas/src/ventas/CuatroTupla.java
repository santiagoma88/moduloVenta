/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

/**
 *4-tupla que contiene un producto , cantidad/unidades de este(si es un servicio sera 1) , 
 * un precioBase(producto*cantidad), y otro campo para el % de descuento o recargo al producto
 * @author Administrador
 */
public class CuatroTupla {
    private AbstractProducto producto;
    private int cantidad;
    private double precioBase;
    
    private double porcentaje;

    /**
     * Crea una 4-tupla 
     * @param producto producto
     * @param cantidad numero de unidades de un bien
     */
    protected CuatroTupla(AbstractProducto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;             
        this.precioBase= cantidad *this.producto.getPrecioBrutoUnidad();
        this.porcentaje=100;
    }

    /**
     *
     * @return producto perteneciente a la dupla
     */
    public AbstractProducto getProducto() {
        return producto;
    }

    /**
     *
     * @return unidades del producto. Si es un sevicio retorna 1
     */
    public int getCantidad() {
        return cantidad;
    }

    /**
     *
     * @return precioBase correspondiente al precio unitario*numero de unidades
     */
    public double getPrecioBase() {
        return precioBase;
    }

    /**
     *
     * @return porcentaje de precio base que sera utilizado
     * empieza en 100% y segun descuentos o recargos puede bajar o subir
     */
    public double getPorcentaje() {
        return porcentaje;
    }

    protected void setPorcentaje(double porcentaje) {
        this.porcentaje = porcentaje;
    }

    @Override
    public String toString() {
        return "CuatroTupla{" + "producto=" + producto + ", cantidad=" + cantidad + ", precioBase=" + precioBase + ", porcentaje=" + porcentaje + '}';
    }

    
    
    
    
    
    
    
}
