/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

/**
 *Interfaz que define el comportamiento del carrito de compras
 * No permite productos repetidos asi tengan diferendtes cantidades
 * @author Administrador
 */
public interface ICarrito {    
    
    /**
     *Añade un AbstractProducto al carrito y define su cantidad(unidades), el carrito no permite repeticion de productos
     * No permite repeticion de productos      
     * @see  AbstractProducto#equals(java.lang.Object)       utiliza equals()
     * 
     * @param producto AbstractProducto a añadir al carrito 
     * @param cantidad  unidades de dicho producto, si el ingresado es menor a 1 o el producto ingresado 
     * es un servicio, se registrara como 1 por defecto  
     * @return true si se añadio el objeto false si ya estaba y no se modifico el carrito
     * 
     */
    public boolean anadirElemento(AbstractProducto producto, int cantidad);
    
    
    /**
     * Elimina de el carrito el producto 
     * @param producto producto a eliminar
     * @return true si fue eliminado o false si no estaba en el carrito
     */
    public boolean eliminarElemento(AbstractProducto producto);
    
   

    /**
     *  Elimina todos los elementos de el carrito
     */
    public void vaciarCarrito();    
    
}
